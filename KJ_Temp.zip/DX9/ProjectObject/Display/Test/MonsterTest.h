#pragma once

//enum PlayerStatus
//{
//	Player_Stand,
//	Player_Run,
//	Player_JumpStart,
//	Player_Jumping,
//	Player_JumpEnd,
//	Status_End
//};

class MonsterTest : public IDisplayObject
{
public:

	MonsterTest();
	~MonsterTest();

	// IDisplayObject��(��) ���� ��ӵ�
	virtual void Init() override;
	virtual void Update() override;
	virtual void Render() override;
	virtual void Render(IShader* pShader) override;

	virtual void Draw() override;


private:

	PlayerStatus status;

	vector<IDisplayObject*> cowMotion;

};