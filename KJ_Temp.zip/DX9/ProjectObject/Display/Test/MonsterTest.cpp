#include "stdafx.h"
#include "MonsterTest.h"

MonsterTest::MonsterTest()
{
	status = Player_Stand;
	//scale = D3DXVECTOR3(.1, .1, .1);


	cowMotion.push_back(new SkinnedMeshHLSL((ASSET_PATH + L"Models/X/Cow/").c_str(), L"CowStand.X"));
	cowMotion.push_back(new SkinnedMeshHLSL((ASSET_PATH + L"Models/X/Cow/").c_str(), L"CowRun.X"));
	cowMotion.push_back(new SkinnedMeshHLSL((ASSET_PATH + L"Models/X/Cow/").c_str(), L"CowJumpStart.X"));
	cowMotion.push_back(new SkinnedMeshHLSL((ASSET_PATH + L"Models/X/Cow/").c_str(), L"CowJumping.X"));
	cowMotion.push_back(new SkinnedMeshHLSL((ASSET_PATH + L"Models/X/Cow/").c_str(), L"CowJumpEnd.X"));

	for (int i = 0; i < Status_End; ++i)
		cowMotion[i]->Init();


	Rendering::Get()->AddRenderingObject(cowMotion[status]);

	

	boundary = new BoundingSphere(D3DXVECTOR3(0, 0, 0), 10.f);
	boundary->InitGeometry();


}

MonsterTest::~MonsterTest()
{
}

void MonsterTest::Init()
{
}

void MonsterTest::Update()
{
	position = D3DXVECTOR3(2, 0, 5);

	IDisplayObject::ApplyVelocity();
	IDisplayObject::UpdateLocalMatrix();
	IDisplayObject::UpdateWorldMatrix();

	boundary->UpdateTransform(worldMatrix);


	list<IDisplayObject*> m_mapList;
	m_mapList = Objects::FindObjectsByTag(TAG_MAP);
	list<IMap*> mapList;
	for (auto p : m_mapList)
	{
		mapList.push_back((IMap*)p);
	}

	for (auto p : mapList)
	{
		if (mapList.empty() == false)
		{
			if (velocity.y <= 0)
			{
				float height;

				if (p->ComputeHeight(height, targetPosition))
				{
					if (targetPosition.y <= height)
					{
						targetPosition.y = height;
						velocity.y = 0;
					}
					position = targetPosition;
				}
			}
			else
			{
				position = targetPosition;
			}
		}
		else
		{
			position = targetPosition;
		}
	}
	cowMotion[status]->Update();



}

void MonsterTest::Render()
{

	//dynamic_cast<BoundingSphere*>(boundary)->Render();

}

void MonsterTest::Render(IShader * pShader)
{
	//pShader->Render(this);
	SAFE_RENDER(boundary);

}

void MonsterTest::Draw()
{

}
