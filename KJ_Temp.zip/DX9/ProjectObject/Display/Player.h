#pragma once


class Weapon;

class Player : public IDisplayObject
{
public:
	Player();
	~Player();

	void Init();
	void Update();
	void Render();

	void Delete();

	void UpdateInput();
	void ApplyMap();

private:
	IDisplayObject * face;
	IDisplayObject * body;
	IDisplayObject * tail;

	IDisplayObject * weaponL;
	IDisplayObject * weaponR;

	IDisplayObject * lance;
	Weapon* axe;
	IDisplayObject* fireCube;

	//IDisplayObject* cowJumpStart;
	//IDisplayObject* cowJumping;
	//IDisplayObject* cowJumpEnd;

	vector<IDisplayObject*> cowMotion;

	IDisplayObject* skull;

	PlayerStatus status;
	D3DXVECTOR3 forward;
	D3DXMATRIX matR;
	bool bJumping;
	bool bMoving;

	int skill;

	DWORD curTime;
	DWORD oldTime;
	// - start // 2-ing // 3-end

	//Boundary* boundary;

	// IDisplayObject��(��) ���� ��ӵ�
	virtual void Draw() override;

};