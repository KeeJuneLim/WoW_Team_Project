#include "stdafx.h"
#include "Player.h"
#include "Graphics\Model\X\AllocateHierarchyHLSL.h"
#include "ProjectObject\Display\Weapon.h"
#include "ProjectObject\Display\ShaderCube.h"
#include "Graphics\Model\OBJ\ObjMap.h"
#include "ProjectObject\Display\Skill\SkullMissile.h"


Player::Player()
{
	bJumping = false;
	bMoving = false;
	scale = D3DXVECTOR3(.1, .1, .1);
	skill = 0;

	//////

	/////
	status = Player_Stand;

	cowMotion.push_back(new SkinnedMeshHLSL((ASSET_PATH + L"Models/X/Tuskarr/").c_str(), L"Tuskarr_Stand.X"));
	cowMotion.push_back(new SkinnedMeshHLSL((ASSET_PATH + L"Models/X/Tuskarr/").c_str(), L"Tuskarr_Run.X"));
	cowMotion.push_back(new SkinnedMeshHLSL((ASSET_PATH + L"Models/X/Tuskarr/").c_str(), L"Tuskarr_Spell.X"));


	for (int i = 0; i < Status_End; ++i)
		cowMotion[i]->Init();

	Rendering::Get()->AddRenderingObject(cowMotion[status]);



	boundary = new BoundingSphere(D3DXVECTOR3(0, 0, 0), 18.f);
	boundary->InitGeometry();

	//Rendering::Get()->AddRenderingObject(this);

}

Player::~Player()
{



}

void Player::Init()
{


}

void Player::Update()
{
	Camera::Get()->UpdateRotation();
	rotation.y = Camera::Get()->GetCurrentRotation()->y;
	D3DXMatrixRotationY(&matR, rotation.y); // forward ����
	D3DXVec3TransformNormal(&forward,
		&D3DXVECTOR3(0, 0, 1),
		&matR);
	D3DXVec3Normalize(&forward, &forward);


	Rendering::Get()->RemoveRenderingObject(cowMotion[status]);

	UpdateInput();


	IDisplayObject::UpdateInput();
	IDisplayObject::ApplyInput();
	IDisplayObject::ApplyVelocity();


	/*skull->SetPosition(&position);
	skull->SetRotation(&rotation);*/
	cowMotion[status]->SetPosition(&position);
	cowMotion[status]->SetRotation(&rotation);
	Rendering::Get()->AddRenderingObject(cowMotion[status]);



	LPD3DXANIMATIONSET pCurrAnimSet = NULL;
	D3DXTRACK_DESC track;
	dynamic_cast<SkinnedMeshHLSL*>(cowMotion[status])->m_pAC->GetTrackDesc(0, &track);
	dynamic_cast<SkinnedMeshHLSL*>(cowMotion[status])->m_pAC->GetAnimationSet(0, &pCurrAnimSet);

	if (pCurrAnimSet->GetPeriodicPosition(track.Position)
		>= pCurrAnimSet->GetPeriod() - 0.02f)
	{
		Rendering::Get()->RemoveRenderingObject(cowMotion[status]);

		dynamic_cast<SkinnedMeshHLSL*>(cowMotion[status])->m_pAC->SetTrackPosition(0, 0);

		if (status == Player_Spell)
			status = Player_Stand;
	
	}

	cowMotion[status]->Update();
	//Rendering::Get()->AddRenderingObject(cowMotion[status]);


	switch (skill)
	{
	case 1:
		curTime = GetTickCount();
		if (curTime - oldTime > 400)
		{
			fireCube = new ShaderCube(position, forward);
			fireCube->Init();
			Scenes::Get()->GetCurrentScene()->AddDisplayObject(fireCube);
			skill = 0;
		}
		break;
	case 2:
		curTime = GetTickCount();
		if (curTime - oldTime > 400)
		{
			IDisplayObject *skull = new SkullMissile(position, forward);
			skull->Init();
			Scenes::Get()->GetCurrentScene()->AddDisplayObject(skull);
			skill = 0;

		}
		break;

	}
	////////////////////

	ApplyMap();
	/////////////////////////////////////////


	ImGui::Begin("Player Status");
	//ImGui::SliderInt("stat", &event, 0, 99);
	ImGui::SliderFloat3("forward", (float*)forward, -10, 10);
	ImGui::End();


}

void Player::Render()
{

}

void Player::Delete()
{
}

void Player::UpdateInput()
{

	if (Input::KeyPress('W'))
	{
		status = Player_Run;
		skill = 0;

	}
	if (Input::KeyUp('W'))
	{
		status = Player_Stand;
			dynamic_cast<SkinnedMeshHLSL*>(cowMotion[Player_Spell])->m_pAC->SetTrackPosition(0, 0);

	}

	if (Input::KeyPress('A'))
	{
		status = Player_Run;
		skill = 0;

	}
	if (Input::KeyUp('A'))
	{
		status = Player_Stand;
		dynamic_cast<SkinnedMeshHLSL*>(cowMotion[Player_Spell])->m_pAC->SetTrackPosition(0, 0);

	}
	if (Input::KeyPress('D'))
	{
		status = Player_Run;
		skill = 0;

	}
	if (Input::KeyUp('D'))
	{
		status = Player_Stand;
		dynamic_cast<SkinnedMeshHLSL*>(cowMotion[Player_Spell])->m_pAC->SetTrackPosition(0, 0);

	}


	//if (Input::KeyDown(VK_SPACE))
	//{
	//	bJumping = true;
	//	status = Player_JumpStart;
	//}



	if (Input::KeyDown('1'))
	{
		status = Player_Spell;

		skill = 1;

		curTime = GetTickCount();
		oldTime = GetTickCount();

	}

	if (Input::KeyDown('2'))
	{
		status = Player_Spell;


		skill = 2;
		curTime = GetTickCount();
		oldTime = GetTickCount();
	}



}

void Player::ApplyMap()
{

	list<IDisplayObject*> m_mapList;
	m_mapList = Objects::FindObjectsByTag(TAG_MAP);
	list<IMap*> mapList;
	for (auto p : m_mapList)
	{
		mapList.push_back((IMap*)p);
	}

	for (auto p : mapList)
	{
		if (mapList.empty() == false)
		{
			if (velocity.y <= 0)
			{
				float height;

				if (p->ComputeHeight(height, targetPosition))
				{
					if (targetPosition.y <= height)
					{
						targetPosition.y = height;
						velocity.y = 0;
					}
					position = targetPosition;
				}
			}
			else
			{
				position = targetPosition;
			}
		}
		else
		{
			position = targetPosition;
		}
	}
}

void Player::Draw()
{
}

