#include "stdafx.h"
#include "ShaderData.h"


HidingData ShaderData::hiding;
ShadowData ShaderData::shadow;